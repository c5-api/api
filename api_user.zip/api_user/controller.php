<?php defined('C5_EXECUTE') or die("Access Denied.");

class ApiUserPackage extends Package {

	protected $pkgHandle = 'api_user';
	protected $appVersionRequired = '5.5.0';
	protected $pkgVersion = '1.0';

	public function getPackageName() {
		return t("Api:User");
	}

	public function getPackageDescription() {
		return t("Provides API user management.");
	}

	public function on_start() {
		Loader::model('user', 'api_user');
		//possibly on_start if we are using a db
		ApiRegistry::extend('user', 'ApiRequest', 'parseRequest', DIR_PACKAGES.'/'.$this->pkgHandle.'/'.DIRNAME_MODELS.'/api_routes.php');
	}

	public function install() {
		$pkg = parent::install();

		$api = array();
		//gotta get this into the DB under the ApiRouteRegistry
		$api['user'][] = array('pkgID' => $this->id,
				       'pkgHandle' => $this->handle,
				       'routeName' => 'User Management',
				       'enabled' => '1',
		       'rateLimit' => '0');

		register($api)
	}

}