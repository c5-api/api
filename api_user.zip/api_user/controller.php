<?php defined('C5_EXECUTE') or die("Access Denied.");

class ApiUserPackage extends Package {

	protected $pkgHandle = 'api_user';
	protected $appVersionRequired = '5.5.0';
	protected $pkgVersion = '1.0';

	public function getPackageName() {
		return t("Api:User");
	}

	public function getPackageDescription() {
		return t("Provides API user management.");
	}

	public function on_start() {
		Loader::model('user', 'api_user');
		//possibly on_start if we are using a db
		//ApiRegister::extend('user', 'ApiRequest', 'parseRequest', DIR_PACKAGES.'/'.$this->pkgHandle.'/'.DIRNAME_MODELS.'/api_routes.php');
	}

	public function install() {
		//$pkg = parent::install();

		$api = array('pkgHandle' => $this->pkgHandle,
				     'routeName' => 'User Management',
				     'enabled' => '1',
				     'isResource' => '0',
		       		 'rateLimit' => '0',
		       		 'rateCount' => '0');

		Loader::model('api_register', 'api');
		$r = new ApiRegister();
		$r->add($api);


	}

}